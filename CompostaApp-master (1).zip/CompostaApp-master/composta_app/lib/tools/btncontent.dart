class BtnContent {
  String text;
  String imageRoute;
  String actionRoute;
  int state;
  BtnContent(this.text, this.imageRoute, this.actionRoute, this.state);
}
