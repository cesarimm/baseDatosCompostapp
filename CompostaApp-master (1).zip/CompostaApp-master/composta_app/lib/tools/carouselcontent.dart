class CarouselWidgetContent {
  String title;
  String description;
  String animation;
  String file;
  CarouselWidgetContent(String title, String description, String file,String animation) {
    this.title = title;
    this.description = description;
    this.file = file;
    this.animation=animation;
  }
}
